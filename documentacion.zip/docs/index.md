---
layout: home

hero:
  name: El Colombiano
  text: Integración Piano - Hey!
  tagline: API que transfiere información de la plataforma Piano a Hey!
  actions:
    - theme: brand
      text: Empieza ahora
      link: /introduction
    - theme: alt
      text: Ver en GitHub
      link: https://github.com/GrupoElColombiano/integracion_hey

[//]: #features:
  - icon: ⚡️
    title: Instalación y configuración
    details: Lorem ipsum...
  - icon: 🖖
    title: Power of Vue meets Markdown
    details: Lorem ipsum...
  - icon: 🛠️
    title: Simple and minimal, always
    details: Lorem ipsum...
---

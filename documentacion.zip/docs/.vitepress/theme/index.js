
import DefaultTheme from 'vitepress/theme'
// import './custom.css'
import './scss/theme.css'

export default DefaultTheme
